import tkinter as tk

root = tk.Tk()
root.title("DarkPhantom VPN")
root.configure(bg="black")
root.geometry("300x200")

label = tk.Label(root, text="DarkPhantom VPN", font=("Arial", 14), fg="cyan", bg="black")
label.pack(pady=20)

button = tk.Button(root, text="Подключиться", bg="cyan", fg="black")
button.pack()

root.mainloop()
